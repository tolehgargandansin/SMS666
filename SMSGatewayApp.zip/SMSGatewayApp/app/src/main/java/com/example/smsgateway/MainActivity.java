﻿package com.example.smsgateway;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.format.Formatter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import org.json.JSONObject;
import org.nanohttpd.protocols.http.IHTTPSession;
import org.nanohttpd.protocols.http.NanoHTTPD;
import org.nanohttpd.protocols.http.response.Response;
import org.nanohttpd.protocols.http.response.Status;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_SEND_SMS = 1;
    private static final int REQUEST_CALL_PHONE = 2;
    private TextView ipTextView, portTextView, statusTextView;
    private ImageView qrImageView;
    private int SERVER_PORT = 8080;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ipTextView = findViewById(R.id.ip_address);
        portTextView = findViewById(R.id.port);
        statusTextView = findViewById(R.id.status);
        qrImageView = findViewById(R.id.qr_image);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SEND_SMS);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL_PHONE);
        }
        String ip = getLocalIpAddress();
        ipTextView.setText("IP: " + ip);
        portTextView.setText("Порт: " + SERVER_PORT);
        String qrData = "http://" + ip + ":" + SERVER_PORT;
        generateQR(qrData);
        startServer();
    }

    private String getLocalIpAddress() {
        try {
            WifiManager wm = (WifiManager) getSystemService(WIFI_SERVICE);
            String ip = Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());
            if (!ip.equals("0.0.0.0")) return ip;
        } catch (Exception e) { e.printStackTrace(); }
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        if (sAddr.contains(".")) return sAddr;
                    }
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return "Не удалось определить IP";
    }

    private void generateQR(String data) {
        try {
            MultiFormatWriter writer = new MultiFormatWriter();
            BitMatrix matrix = writer.encode(data, BarcodeFormat.QR_CODE, 400, 400);
            BarcodeEncoder encoder = new BarcodeEncoder();
            Bitmap bitmap = encoder.createBitmap(matrix);
            qrImageView.setImageBitmap(bitmap);
        } catch (WriterException e) { e.printStackTrace(); }
    }

    private void startServer() {
        new Thread(() -> {
            try {
                SmsServer server = new SmsServer(SERVER_PORT);
                server.start();
                runOnUiThread(() -> statusTextView.setText("Сервер запущен"));
            } catch (IOException e) {
                e.printStackTrace();
                runOnUiThread(() -> statusTextView.setText("Ошибка запуска сервера: " + e.getMessage()));
            }
        }).start();
    }

    private void makeCall(String phoneNumber) {
        try {
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + phoneNumber));
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL_PHONE);
                return;
            }
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            runOnUiThread(() -> Toast.makeText(this, "Ошибка звонка: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private class SmsServer extends NanoHTTPD {
        public SmsServer(int port) { super(port); }
        @Override
        public Response serve(IHTTPSession session) {
            String uri = session.getUri();
            String method = session.getMethod().toString();
            if ("/send".equals(uri) && "POST".equals(method)) {
                try {
                    String body = new String(session.getInputStream().readAllBytes());
                    JSONObject json = new JSONObject(body);
                    String phone = json.getString("phone");
                    String text = json.getString("text");
                    if (phone == null || text == null) {
                        return newFixedLengthResponse(Status.BAD_REQUEST, "application/json", "{\"error\":\"Missing fields\"}");
                    }
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phone, null, text, null, null);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "SMS отправлено на " + phone, Toast.LENGTH_SHORT).show());
                    return newFixedLengthResponse(Status.OK, "application/json", "{\"status\":\"sent\"}");
                } catch (Exception e) {
                    e.printStackTrace();
                    return newFixedLengthResponse(Status.INTERNAL_ERROR, "application/json", "{\"error\":\"" + e.getMessage() + "\"}");
                }
            }
            if ("/call".equals(uri) && "POST".equals(method)) {
                try {
                    String body = new String(session.getInputStream().readAllBytes());
                    JSONObject json = new JSONObject(body);
                    String phone = json.getString("phone");
                    if (phone == null) {
                        return newFixedLengthResponse(Status.BAD_REQUEST, "application/json", "{\"error\":\"Missing phone\"}");
                    }
                    runOnUiThread(() -> makeCall(phone));
                    return newFixedLengthResponse(Status.OK, "application/json", "{\"status\":\"calling\"}");
                } catch (Exception e) {
                    e.printStackTrace();
                    return newFixedLengthResponse(Status.INTERNAL_ERROR, "application/json", "{\"error\":\"" + e.getMessage() + "\"}");
                }
            }
            return newFixedLengthResponse(Status.NOT_FOUND, "text/plain", "Not Found");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Разрешение на SMS получено", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Разрешение на SMS не получено", Toast.LENGTH_LONG).show();
            }
        }
        if (requestCode == REQUEST_CALL_PHONE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Разрешение на звонки получено", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Разрешение на звонки не получено", Toast.LENGTH_LONG).show();
            }
        }
    }
}
